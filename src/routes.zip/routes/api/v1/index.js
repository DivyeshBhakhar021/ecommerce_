const express = require("express");
const router = express.Router();

const categories = require("./categories.routes");
const subcategories = require("./subcategories.routes");
const productes = require("./product.routes");

router.use("/categories", categories)
router.use("/subcategories", subcategories)
router.use("/productes", productes)


module.exports = router