const express = require("express");
const { categoriesController } = require("../../../controller");

const router = express.Router();

router.get(
    "/list-categories",
    categoriesController.listCategories
)

router.post("/addcategories",
    categoriesController.addCategories
 )

router.put(
    "/updateCategories/:category_id",
    categoriesController.updateCategories
)

router.delete("/deleteCategories/:category_id", 
    categoriesController.deleteCategories
)

router.get("/count-subcategories", 
    categoriesController.countsubcategories
)

router.get("/countActiveCategories",
    categoriesController.countActiveCategories
)


module.exports = router